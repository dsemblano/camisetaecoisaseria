<?php
error_reporting(E_ALL & ~E_NOTICE);
define('MULTISITE', false);
define('SUBDOMAIN_INSTALL', false);
define('WPMU_PLUGIN_DIR', null);
define('WP_PLUGIN_DIR', null);
define('WP_USE_THEMES', false);
